package com.example.projectapplication

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.preference.PreferenceManager
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.projectapplication.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    var authMenuItem: MenuItem? = null

    lateinit var sharedPreferences: SharedPreferences

    class MyFragmentAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
        val fragments: List<Fragment>  // fragment연결

        init {   // 초기값 설정
            fragments = listOf(HomeFragment(), SubwayFragment(), UserFragment(), BoardFragment())
        }

        override fun getItemCount(): Int {
            return fragments.size
        }

        override fun createFragment(position: Int): Fragment {
            return fragments[position]  // fragments에서 position번째 fragment를 반환한다
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        val bgColor:String? = sharedPreferences.getString("bg_color", "")   // setting에서 설정시 바로 변경 가능해야하므로 아래 onResume() fun 설정.
        binding.viewpager2.setBackgroundColor(Color.parseColor(bgColor)) // 고쳐야 할 부분

        binding.viewpager2.adapter = MyFragmentAdapter(this)

        val tabList = arrayListOf("홈", "지하철", "내정보", "문의")
        val iconList = ArrayList<Drawable?>()
        iconList.add(ContextCompat.getDrawable(this, R.drawable.house_solid))
        iconList.add(ContextCompat.getDrawable(this, R.drawable.train_subway_solid))
        iconList.add(ContextCompat.getDrawable(this, R.drawable.user_solid))
        iconList.add(ContextCompat.getDrawable(this, R.drawable.iconpaper))

        TabLayoutMediator(binding.tabs, binding.viewpager2) { tab, position ->
            tab.text = tabList[position]
            tab.icon = iconList[position]
        }.attach()
    }

    //add...............................
    override fun onResume() {
        super.onResume()

        val bgColor:String? = sharedPreferences.getString("bg_color", "")
        //binding.viewpager2.setBackgroundColor(Color.parseColor(bgColor))
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)    // 옵션 메뉴 추가

        // 로그인 오류발생
        authMenuItem = menu!!.findItem(R.id.menu_auth)
        if(MyApplication.checkAuth()){  // 로그인 여부 확인
            authMenuItem!!.title = "${MyApplication.email}님"
        } else{ // 로그인 인증이 안된 경우 인증 글자 그대로
            authMenuItem!!.title = "인증"
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onStart(){ // 자동으로 호출되는 함수임. 그럼 언제 불려지냐?
        // Intent에서 finish()  돌아올 때 실행
        // onCreate -> onStart -> onCreateOptionMenu
        super.onStart()
        if(authMenuItem != null) {
            if (MyApplication.checkAuth()) {
                authMenuItem!!.title = "${MyApplication.email}님"
            } else {
                authMenuItem!!.title = "인증"
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {   // 메뉴를 눌렀을 때 반응
        if(item.itemId === R.id.menu_main_setting) {
            val intent = Intent(this, SettingActivity::class.java)   // 약 1시간 30분?
            startActivity(intent)
            return true
        } else if(item.itemId === R.id.menu_auth){
            val intent = Intent(this,AuthActivity::class.java)
            if(authMenuItem!!.title!!.equals("인증")){    // title도 null이 아니기 때문에 !!를 붙여줘야함.
                intent.putExtra("data", "logout")
            }
            else{ // 이메일 또는 구글로 로그인 되어있는 상황
                intent.putExtra("data", "login")    // 로그인 상태라는 것을 전달
            }
            startActivity(intent)    // AuthActivity activity 생성
        }
        return super.onOptionsItemSelected(item)
    }
}