package com.example.projectapplication

data class ItemBoardModel(
    var docId: String? = null,
    var email: String? = null,
    var content: String? = null,
    var date: String? = null,
)
